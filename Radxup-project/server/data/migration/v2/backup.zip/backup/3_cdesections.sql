delete from public."CDESections";
ALTER SEQUENCE public."CDESections_id_seq" RESTART 12;
INSERT INTO public."CDESections" (id,"order","name",created_by,created_at,updated_by,updated_at,linked_variable_name,question_attributes_list,question_attributes_label,cde_version,cde_status) VALUES
	 (1,1,'Location',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (2,2,'Sociodemographics',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (3,3,'Housing, Employment and Insurance',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (4,4,'Medical History',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (5,5,'Health Status',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (6,6,'Vaccine Acceptance',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (7,7,'Testing',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (8,8,'Covid Test',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (9,9,'Symptoms',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (10,10,'Alcohol and Tobacco',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active'),
	 (11,11,'Identity',1,'2022-01-09 23:53:48.589092+05:30',1,'2022-01-09 23:53:48.589092+05:30',NULL,NULL,'','10.13_RADx-UP_CDE_1.4_JDT_upd022322','Active');